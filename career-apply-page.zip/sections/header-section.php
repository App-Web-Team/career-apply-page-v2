<head>
    <link rel="stylesheet" href="assets/styles/style-header.css">
</head>

<div class="fullscreen">
    <div class="gradient-background">
        <!-- notification bar -->
        <?php
        include "notification-bar.php";
        include "career-apply-section-new.php";
        ?>
    </div>
</div>